import sys

def get_args() -> list:
    """Get command line arguments.
    Return a list."""
    return sys.argv[1:]
