# ft_package

Personnal features library.

## Installation


## Usage

TODO: Add usage examples

## License

MIT